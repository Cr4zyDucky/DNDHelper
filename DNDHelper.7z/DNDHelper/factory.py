from character import Fighter, Wizard, Barbarian, Bard, Cleric, Monk, Druid

class CharacterFactory:
    @staticmethod
    def create_character(char_type, name, history):
        if char_type == "fighter":
            return Fighter(name, history)
        elif char_type == "wizard":
            return Wizard(name, history)
        elif char_type == "barbarian":
            return Barbarian(name, history)
        elif char_type == "bard":
            return Bard(name, history)
        elif char_type == "cleric":
            return Cleric(name, history)
        elif char_type == "monk":
            return Monk(name, history)
        elif char_type == "druid":
            return Druid(name, history)
        else:
            raise ValueError("Invalid character type")

# Usage:
gimli = CharacterFactory.create_character("fighter", "Gimli", "Dwarven warrior")