import json
from factory import CharacterFactory

class GameMaster:
    def __init__(self):
        self.loaded_characters = {}  # {filename: Character object}

    def load_character(self, filename):
        try:
            with open(filename, 'r') as f:
                data = json.load(f)
            char = CharacterFactory.create_character(
                data["class"].lower(),
                data["name"],
                data["history"]
            )
            char.stats.values = data["stats"]
            char.hp = data["hp"]
            char.inventory.items = data["inventory"]
            char.abilities = data["abilities"]
            self.loaded_characters[filename] = char
            print(f"Loaded {char.name} (HP: {char.hp}/{char.max_hp})")
        except Exception as e:
            print(f"Error loading {filename}: {e}")

    def damage_character(self, filename, amount):
        char = self.loaded_characters.get(filename)
        if char:
            char.hp -= amount
            print(f"{char.name} took {amount} damage! (HP: {char.hp}/{char.max_hp})")

    def heal_character(self, filename, amount):
        char = self.loaded_characters.get(filename)
        if char:
            char.hp += amount
            print(f"{char.name} healed by {amount}! (HP: {char.hp}/{char.max_hp})")

    def list_characters(self):
        print("\n=== Loaded Characters ===")
        for filename, char in self.loaded_characters.items():
            print(f"{filename}: {char.name} ({char.__class__.__name__}) - HP: {char.hp}/{char.max_hp}")