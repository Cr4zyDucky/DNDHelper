from abc import ABC, abstractmethod

class Stats:
    def __init__(self, str_=10, dex=10, con=10, int_=10, wis=10, cha=10):
        self.values = {
            "STR": str_,
            "DEX": dex,
            "CON": con,
            "INT": int_,
            "WIS": wis,
            "CHA": cha
        }

    def update_stat(self, stat, value):
        if stat in self.values:
            self.values[stat] = value

    def to_dict(self):
        return self.values

class Inventory:
    def __init__(self):
        self.items = []

    def add_item(self, item):
        self.items.append(item)

    def remove_item(self, item_name):
        for i, item in enumerate(self.items):
            if item.lower() == item_name.lower():
                return self.items.pop(i)
        return None

    def to_list(self):
        return self.items

    def to_list(self):
        return self.items

class AbstractCharacter(ABC):
    def __init__(self, name, history):
        self.name = name
        self.history = history
        self.stats = Stats()
        self.inventory = Inventory()
        self.abilities = []
        self._base_max_hp = 10
        self._hp = self.max_hp

    @property
    def max_hp(self):
        return self._base_max_hp + self.stats.values["CON"]

    @property
    def hp(self):
        return self._hp

    @hp.setter
    def hp(self, value):
        self._hp = max(0, min(value, self.max_hp))

    @abstractmethod
    def special_ability(self):
        pass

    def add_ability(self, ability):
        if ability not in self.abilities:
            self.abilities.append(ability)

    def to_dict(self):
        return {
            "name": self.name,
            "class": self.__class__.__name__,
            "history": self.history,
            "hp": self.hp,
            "stats": self.stats.to_dict(),
            "inventory": self.inventory.to_list(),
            "abilities": self.abilities
        }

class Fighter(AbstractCharacter):
    def __init__(self, name, history):
        super().__init__(name, history)
        self._base_max_hp = 10  
        self._hp = self.max_hp  
        self.abilities.append(self.special_ability())

    def special_ability(self):
        return "Power Attack"

class Wizard(AbstractCharacter):
    def __init__(self, name, history):
        super().__init__(name, history)
        self._base_max_hp = 2  
        self._hp = self.max_hp
        self.abilities.append(self.special_ability())

    def special_ability(self):
        return "Fireball"
    
class Barbarian(AbstractCharacter):
    def __init__(self, name, history):
        super().__init__(name, history)
        self._base_max_hp = 12
        self.hp = self.max_hp
        self.abilities.append(self.special_ability())

    def special_ability(self):
        return "Danger Sense"
    
class Bard(AbstractCharacter):
    def __init__(self, name, history):
        super().__init__(name, history)
        self._base_max_hp = 8
        self.hp = self.max_hp
        self.abilities.append(self.special_ability())

    def special_ability(self):
        return "Bardic Inspiration"
    
class Cleric(AbstractCharacter):
    def __init__(self, name, history):
        super().__init__(name, history)
        self._base_max_hp = 8
        self.hp = self.max_hp
        self.abilities.append(self.special_ability())

    def special_ability(self):
        return "Channel Divinity"
    
class Druid(AbstractCharacter):
    def __init__(self, name, history):
        super().__init__(name, history)
        self._base_max_hp = 8
        self.hp = self.max_hp
        self.abilities.append(self.special_ability())

    def special_ability(self):
        return "Wild Shape"
    
class Monk(AbstractCharacter):
    def __init__(self, name, history):
        super().__init__(name, history)
        self._base_max_hp = 8
        self.hp = self.max_hp
        self.abilities.append(self.special_ability())

    def special_ability(self):
        return "Ki"