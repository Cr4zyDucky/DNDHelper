import json
from factory import CharacterFactory  

class CharacterFileHandler:
    @staticmethod
    def save_character(character, filename):
        data = character.to_dict()
        with open(filename, 'w') as f:
            json.dump(data, f)

    @staticmethod
    def load_character(filename):
        with open(filename, 'r') as f:
            data = json.load(f)
        char = CharacterFactory.create_character(
            data["class"].lower(), 
            data["name"], 
            data["history"]
        )
        char.stats.values = data["stats"]
        char.hp = data["hp"]
        char.inventory.items = data["inventory"]
        char.abilities = data["abilities"]
    
        return char