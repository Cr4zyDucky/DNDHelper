import json
from factory import CharacterFactory
from SaveAndLoad import CharacterFileHandler
from gamemaster import GameMaster


class CharacterCLI:
    def __init__(self):
        self.current_character = None
        self.gm_mode = False
        self.gm = GameMaster() if input("Are you the Game Master? (y/n): ").lower() == 'y' else None
        self.gm_mode = bool(self.gm)

    def start(self):
        if self.gm_mode:
            self.gm_menu()
        else:
            self.create_character()

    def gm_menu(self):
        while True:
            print("\n=== GM Mode ===")
            print("1. Load Character")
            print("2. Damage Character")
            print("3. Heal Character")
            print("4. List Characters")
            print("5. Exit")
            choice = input("Choose an option: ")

            if choice == "1":
                filename = input("Enter character filename: ")
                self.gm.load_character(filename)
            elif choice == "2":
                filename = input("Enter character filename: ")
                amount = int(input("Damage amount: "))
                self.gm.damage_character(filename, amount)
            elif choice == "3":
                filename = input("Enter character filename: ")
                amount = int(input("Heal amount: "))
                self.gm.heal_character(filename, amount)
            elif choice == "4":
                self.gm.list_characters()
            elif choice == "5":
                break
            else:
                print("Invalid choice.")


    def create_character(self):
        char_type = input("Choose class (fighter/wizard/monk/bard/barbarian/druid/cleric): ").lower() 
        name = input("Enter character name: ")
        history = input("Enter character history: ")
        

        try:
            self.current_character = CharacterFactory.create_character(
                char_type, name, history
            )
            print(f"{name} created! ({char_type.capitalize()})")
            self.character_menu()
        except ValueError as e:
            print(f"Error: {e}")

    def character_menu(self):
        while True:
            print("\n=== Character Menu ===")
            print("1. Edit Stats")
            print("2. Add Item")
            print("3. Add Ability")
            print("4. Delete Item")
            print("5. Take Damage")  
            print("6. Heal")           
            print("7. View Character")
            print("8. Save Character")
            print("9. EXIT")  

            choice = input("Choose an option: ")

            if choice == "1":
                self.edit_stats()
            elif choice == "2":
                self.add_item()
            elif choice == "3":
                self.add_ability()
            elif choice == "4":
                self.delete_item()
            elif choice == "5":
                self.take_damage()    
            elif choice == "6":
                self.heal()           
            elif choice == "7":
                self.view_character()
            elif choice == "8":
                self.save_character()
            elif choice == "9":
                if self.confirm_exit():
                    self.current_character = None
                    break
            else:
                print("Invalid choice. Try again.")

    def edit_stats(self):
        print("\nEdit Stats (enter new values):")
        for stat_name in self.current_character.stats.values.keys():
            while True:
                try:
                    new_value = int(input(f"{stat_name}: "))
                    old_con = self.current_character.stats.values["CON"]
                    self.current_character.stats.update_stat(stat_name, new_value)
                    if stat_name == "CON":
                        con_increase = new_value - old_con
                        if con_increase > 0:
                            self.current_character.hp += con_increase
                            print(f"CON increased! Gained {con_increase} HP (now: {self.current_character.hp}/{self.current_character.max_hp}).")
                        elif con_increase < 0:
                            self.current_character.hp = min(self.current_character.hp, self.current_character.max_hp)  
                    break
                except ValueError:
                    print("Please enter a number.")
        print("Stats updated!")

    def add_item(self):
        item = input("Enter item name: ")
        self.current_character.inventory.add_item(item)
        print(f"{item} added to inventory!")

    def delete_item(self):
        if not self.current_character.inventory.items:
            print("Inventory is empty!")
            return

        print("\nCurrent Inventory:")
        for i, item in enumerate(self.current_character.inventory.items, 1):
            print(f"{i}. {item}")

        item_name = input("\nEnter item name to delete: ").strip()
        removed = self.current_character.inventory.remove_item(item_name)
        
        if removed:
            print(f"Removed '{removed}' from inventory!")
        else:
            print(f"Item '{item_name}' not found in inventory.")

    def view_character(self):
        try:
            char_data = self.current_character.to_dict()
            print("\n=== Character Sheet ===")
            for key, value in char_data.items():
                print(f"{key.capitalize()}: {value}")
        except AttributeError:
            print("Error: Character data is missing or invalid.")
        except Exception as e:
            print(f"Unexpected error: {e}")

    def save_character(self):
        filename = input("Enter filename to save (e.g., gimli.json): ")
        CharacterFileHandler.save_character(self.current_character, filename)
        print(f"Character saved to {filename}!")

    def load_character(self):
        filename = input("Enter filename to load: ")
        try:
            self.current_character = CharacterFileHandler.load_character(filename)
            print(f"Character loaded successfully!")
            self.character_menu()
        except FileNotFoundError:
            print("File not found!")
        except json.JSONDecodeError:
            print("Invalid file format!")
    
    def add_ability(self):
        ability = input("Enter ability name: ").strip()
        if ability: 
            self.current_character.add_ability(ability)
            print(f"'{ability}' added to abilities!")
        else:
            print("Ability name cannot be empty.")


    def take_damage(self):
        try:
            damage = int(input("Enter damage amount: "))
            self.current_character.hp -= damage 
            print(f"Took {damage} damage! Current HP: {self.current_character.hp}")
        except ValueError:
            print("Please enter a number.")

    def confirm_exit(self):
        while True:
            confirm = input("Are you sure you want to exit? Unsaved changes will be lost. (y/n): ").lower()
            if confirm == 'y':
                return True
            elif confirm == 'n':
                return False
            else:
                print("Please enter 'y' or 'n'.")

    def heal(self):
            try:
                heal_amount = int(input("Enter heal amount: "))
                self.current_character.hp += heal_amount 
                print(f"Healed {heal_amount} HP! Current HP: {self.current_character.hp}")
            except ValueError:
                print("Please enter a number.")



if __name__ == "__main__":
    cli = CharacterCLI()
    cli.start()