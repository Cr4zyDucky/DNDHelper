import unittest
import os
import json
from tempfile import NamedTemporaryFile
from character import AbstractCharacter, Fighter, Wizard, Stats, Inventory
from factory import CharacterFactory
from SaveAndLoad import CharacterFileHandler
from CLI import CharacterCLI
from gamemaster import GameMaster

class TestDNDSystem(unittest.TestCase):
    def setUp(self):
        # Create test characters
        self.fighter = Fighter("Conan", "Fighter")
        self.wizard = Wizard("Gandalf", "Wizard")
        
        # Create test items
        self.fighter.inventory.add_item("Axe")
        self.wizard.inventory.add_item("Staff")
        
        # Temp file for I/O tests
        self.temp_file = NamedTemporaryFile(delete=False, suffix=".json")
        self.temp_file.close()

    def tearDown(self):
        if os.path.exists(self.temp_file.name):
            os.unlink(self.temp_file.name)

    # --- Core Character Tests ---
    def test_character_creation(self):
        self.assertEqual(self.fighter.name, "Conan")
        self.assertEqual(self.wizard.hp, self.wizard.max_hp)
        self.assertIn("Power Attack", self.fighter.abilities)

    def test_hp_management(self):
        self.fighter.hp -= 5
        self.assertEqual(self.fighter.hp, 15)  # Fighter starts with 20 HP
        self.fighter.hp += 100
        self.assertEqual(self.fighter.hp, self.fighter.max_hp)  # Test clamping

    def test_con_stat_affects_max_hp(self):
        old_max = self.fighter.max_hp
        self.fighter.stats.update_stat("CON", self.fighter.stats.values["CON"] + 2)
        self.assertEqual(self.fighter.max_hp, old_max + 2)

    # --- Inventory Tests ---
    def test_inventory_add(self):
        self.fighter.inventory.add_item("Shield")
        self.assertIn("Shield", self.fighter.inventory.items)

    def test_inventory_remove(self):
        self.assertTrue(self.fighter.inventory.remove_item("Axe"))
        self.assertNotIn("Axe", self.fighter.inventory.items)
        self.assertFalse(self.fighter.inventory.remove_item("Nonexistent"))

    # --- File I/O Tests ---
    def test_save_and_load(self):
        CharacterFileHandler.save_character(self.fighter, self.temp_file.name)
        loaded = CharacterFileHandler.load_character(self.temp_file.name)
        self.assertEqual(loaded.name, "Conan")
        self.assertEqual(loaded.inventory.items, ["Axe"])

    def test_load_invalid_file(self):
        with open(self.temp_file.name, 'w') as f:
            f.write("invalid json")
        with self.assertRaises(json.JSONDecodeError):
            CharacterFileHandler.load_character(self.temp_file.name)

    # --- GM Mode Tests ---
    def test_gm_character_management(self):
        gm = GameMaster()
        
        # Save test character first
        CharacterFileHandler.save_character(self.fighter, self.temp_file.name)
        
        gm.load_character(self.temp_file.name)
        self.assertIn(self.temp_file.name, gm.loaded_characters)
        
        gm.damage_character(self.temp_file.name, 5)
        self.assertEqual(gm.loaded_characters[self.temp_file.name].hp, 15)
        
        gm.heal_character(self.temp_file.name, 3)
        self.assertEqual(gm.loaded_characters[self.temp_file.name].hp, 18)

    # --- CLI Tests ---
    def test_cli_mode_selection(self):
        # Mock input for player mode
        cli = CharacterCLI()
        cli.gm_mode = False
        self.assertFalse(cli.gm_mode)
        
        # Mock input for GM mode
        cli.gm_mode = True
        self.assertTrue(cli.gm_mode)

if __name__ == "__main__":
    unittest.main()